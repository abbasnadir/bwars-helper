import html

from pytz import timezone

from chat_exporter.ext.discord_import import discord
from chat_exporter.ext.export_context import current
from chat_exporter.ext.html_generator import (
    PARSE_MODE_EMBED,
    PARSE_MODE_MARKDOWN,
    PARSE_MODE_NONE,
    PARSE_MODE_SPECIAL_EMBED,
    embed_author,
    embed_author_icon,
    embed_body,
    embed_description,
    embed_field,
    embed_field_inline,
    embed_footer,
    embed_footer_icon,
    embed_image,
    embed_thumbnail,
    embed_title,
    fill_out,
)
from chat_exporter.ext.sanitize import safe_url

modules_which_use_none = ["nextcord", "disnake"]


def _gather_checker():
    if discord.module not in modules_which_use_none and hasattr(discord.Embed, "Empty"):
        return discord.Embed.Empty
    return None


class Embed:
    r: str
    g: str
    b: str
    title: str
    description: str
    author: str
    image: str
    thumbnail: str
    footer: str
    fields: str

    check_against = None

    def __init__(self, embed, guild, pytz_timezone=None, military_time=True):
        self.embed: discord.Embed = embed
        self.guild: discord.Guild = guild
        self.pytz_timezone = pytz_timezone
        self.military_time = military_time

    async def flow(self):
        self.check_against = _gather_checker()
        self.build_colour()
        await self.build_title()
        await self.build_description()
        await self.build_fields()
        await self.build_author()
        await self.build_image()
        await self.build_thumbnail()
        await self.build_footer()
        await self.build_embed()

        return self.embed

    def build_colour(self):
        self.r, self.g, self.b = (
            (self.embed.colour.r, self.embed.colour.g, self.embed.colour.b)
            if self.embed.colour != self.check_against
            else (0x4A, 0x4A, 0x50)
        )

    def _format_embed_timestamp(self) -> str:
        timestamp = getattr(self.embed, "timestamp", None)
        if not timestamp or timestamp == self.check_against:
            return ""

        time_value = timestamp
        if not getattr(time_value, "tzinfo", None):
            time_value = timezone("UTC").localize(time_value)

        tz_name = self.pytz_timezone or current().timezone or getattr(self.guild, "timezone", "UTC") or "UTC"
        try:
            tz = timezone(tz_name)
        except Exception:
            tz = timezone("UTC")

        local_time = time_value.astimezone(tz)
        if self.military_time:
            return local_time.strftime("%d-%m-%Y %H:%M")
        return local_time.strftime("%d-%m-%Y %I:%M %p")

    async def build_title(self):
        raw_title = html.escape(self.embed.title) if self.embed.title != self.check_against else ""

        if not raw_title:
            self.title = ""
            return

        title_html = await fill_out(self.guild, "{{EMBED_TITLE}}", [("EMBED_TITLE", raw_title, PARSE_MODE_MARKDOWN)])

        url_value = getattr(self.embed, "url", self.check_against)
        href = safe_url(url_value) if url_value and url_value != self.check_against else ""
        if href:
            title_html = f'<a href="{href}">{title_html}</a>'

        self.title = await fill_out(self.guild, embed_title, [("EMBED_TITLE", title_html, PARSE_MODE_NONE)])

    async def build_description(self):
        escaped_description = (
            html.escape(self.embed.description) if self.embed.description != self.check_against else ""
        )
        self.description = ""

        if escaped_description:
            self.description = await fill_out(
                self.guild, embed_description, [("EMBED_DESC", escaped_description, PARSE_MODE_EMBED)]
            )

    async def build_fields(self):
        self.fields = ""

        # This does not have to be here, but Pycord.
        if not self.embed.fields:
            return

        rows = []
        current_row = []
        for field in self.embed.fields:
            if not getattr(field, "inline", False):
                if current_row:
                    rows.append(current_row)
                    current_row = []
                rows.append([field])
            else:
                current_row.append(field)
                if len(current_row) == 3:
                    rows.append(current_row)
                    current_row = []
        if current_row:
            rows.append(current_row)

        for row in rows:
            if len(row) == 1 and not getattr(row[0], "inline", False):
                field = row[0]
                self.fields += await fill_out(
                    self.guild,
                    embed_field,
                    [
                        ("FIELD_NAME", html.escape(field.name), PARSE_MODE_SPECIAL_EMBED),
                        ("FIELD_VALUE", html.escape(field.value), PARSE_MODE_EMBED),
                        ("GRID_COLUMN", "1 / 13", PARSE_MODE_NONE),
                    ],
                )
            else:
                if len(row) == 3:
                    cols = ["1 / 5", "5 / 9", "9 / 13"]
                elif len(row) == 2:
                    cols = ["1 / 7", "7 / 13"]
                else:
                    cols = ["1 / 13"]

                for idx, field in enumerate(row):
                    self.fields += await fill_out(
                        self.guild,
                        embed_field_inline,
                        [
                            ("FIELD_NAME", html.escape(field.name), PARSE_MODE_SPECIAL_EMBED),
                            ("FIELD_VALUE", html.escape(field.value), PARSE_MODE_EMBED),
                            ("GRID_COLUMN", cols[idx], PARSE_MODE_NONE),
                        ],
                    )

    async def build_author(self):
        self.author = (
            html.escape(self.embed.author.name)
            if (self.embed.author and self.embed.author.name != self.check_against)
            else ""
        )

        author_url = (
            safe_url(self.embed.author.url)
            if (self.embed.author and self.embed.author.url != self.check_against)
            else ""
        )
        if author_url:
            self.author = f'<a class="chatlog__embed-author-name-link" href="{author_url}">{self.author}</a>'

        author_icon_url = (
            safe_url(self.embed.author.icon_url)
            if (self.embed.author and self.embed.author.icon_url != self.check_against)
            else ""
        )
        author_icon = (
            await fill_out(
                self.guild,
                embed_author_icon,
                [
                    ("AUTHOR", self.author, PARSE_MODE_NONE),
                    ("AUTHOR_ICON", author_icon_url, PARSE_MODE_NONE),
                ],
            )
            if author_icon_url
            else ""
        )

        if author_icon == "" and self.author != "":
            self.author = await fill_out(self.guild, embed_author, [("AUTHOR", self.author, PARSE_MODE_NONE)])
        else:
            self.author = author_icon

    async def build_image(self):
        image_url = (
            safe_url(self.embed.image.url)
            if (self.embed.image and self.embed.image.url != self.check_against)
            else ""
        )
        self.image = (
            await fill_out(self.guild, embed_image, [("EMBED_IMAGE", image_url, PARSE_MODE_NONE)])
            if image_url
            else ""
        )

    async def build_thumbnail(self):
        thumb_url = (
            safe_url(self.embed.thumbnail.url)
            if (self.embed.thumbnail and self.embed.thumbnail.url != self.check_against)
            else ""
        )
        self.thumbnail = (
            await fill_out(self.guild, embed_thumbnail, [("EMBED_THUMBNAIL", thumb_url, PARSE_MODE_NONE)])
            if thumb_url
            else ""
        )

    async def build_footer(self):
        footer_text = (
            html.escape(self.embed.footer.text)
            if (self.embed.footer and self.embed.footer.text != self.check_against)
            else ""
        )

        footer_icon = (
            safe_url(self.embed.footer.icon_url)
            if (self.embed.footer and self.embed.footer.icon_url != self.check_against)
            else ""
        )

        timestamp_text = self._format_embed_timestamp()
        if footer_text and timestamp_text:
            footer_text = f"{footer_text} | {timestamp_text}"
        elif not footer_text and timestamp_text:
            footer_text = timestamp_text

        if not footer_text:
            self.footer = ""
            return

        if footer_icon:
            self.footer = await fill_out(
                self.guild,
                embed_footer_icon,
                [("EMBED_FOOTER", footer_text, PARSE_MODE_NONE), ("EMBED_FOOTER_ICON", footer_icon, PARSE_MODE_NONE)],
            )
        else:
            self.footer = await fill_out(self.guild, embed_footer, [("EMBED_FOOTER", footer_text, PARSE_MODE_NONE)])

    async def build_embed(self):
        self.embed = await fill_out(
            self.guild,
            embed_body,
            [
                ("EMBED_R", str(int(self.r)), PARSE_MODE_NONE),
                ("EMBED_G", str(int(self.g)), PARSE_MODE_NONE),
                ("EMBED_B", str(int(self.b)), PARSE_MODE_NONE),
                ("EMBED_AUTHOR", self.author, PARSE_MODE_NONE),
                ("EMBED_TITLE", self.title, PARSE_MODE_NONE),
                ("EMBED_IMAGE", self.image, PARSE_MODE_NONE),
                ("EMBED_THUMBNAIL", self.thumbnail, PARSE_MODE_NONE),
                ("EMBED_DESC", self.description, PARSE_MODE_NONE),
                ("EMBED_FIELDS", self.fields, PARSE_MODE_NONE),
                ("EMBED_FOOTER", self.footer, PARSE_MODE_NONE),
            ],
        )
