import html
import re
from datetime import timedelta
from typing import List, Optional

from pytz import timezone

from chat_exporter.construct.assets import Attachment, AttachmentGrid, Component, Embed, Reaction
from chat_exporter.construct.attachment_handler import AttachmentHandler
from chat_exporter.ext.cache import cache
from chat_exporter.ext.discord_import import discord
from chat_exporter.ext.discord_utils import DiscordUtils
from chat_exporter.ext.discriminator import discriminator
from chat_exporter.ext.html_generator import (
    PARSE_MODE_MARKDOWN,
    PARSE_MODE_NONE,
    PARSE_MODE_REFERENCE,
    PARSE_MODE_TEXT,
    PARSE_MODE_URL,
    bot_tag,
    bot_tag_verified,
    end_message,
    fill_out,
    img_attachment,
    message_body,
    message_content,
    message_forwarded,
    message_interaction,
    message_pin,
    message_reference,
    message_reference_unknown,
    message_thread,
    message_thread_add,
    message_thread_remove,
    start_message,
)
from chat_exporter.ext.sanitize import escape, safe_url


def _gather_user_bot(author: discord.Member):
    if author.bot and author.public_flags.verified_bot:
        return bot_tag_verified
    elif author.bot:
        return bot_tag
    return ""


def _set_edit_at(message_edited_at):
    return f'<span class="chatlog__reference-edited-timestamp" data-timestamp="{message_edited_at}">(edited)</span>'


class MessageConstruct:
    message_html: str = ""

    # Asset Types
    embeds: str = ""
    forwarded_embeds: str = ""
    reactions: str = ""
    components: str = ""
    attachments: str = ""
    time_format: str = ""

    interaction: str = ""

    def __init__(
        self,
        message: discord.Message,
        previous_message: Optional[discord.Message],
        pytz_timezone,
        military_time: bool,
        guild: discord.Guild,
        meta_data: dict,
        message_dict: dict,
        attachment_handler: Optional[AttachmentHandler],
        fetch_reactors: bool = True,
    ):
        self.message = message
        self.rendered_content = ""
        self.previous_message = previous_message
        self.pytz_timezone = pytz_timezone
        self.military_time = military_time
        self.guild = guild
        self.message_dict = message_dict
        self.attachment_handler = attachment_handler
        self.fetch_reactors = fetch_reactors
        self.time_format = "%A, %e %B %Y %I:%M %p"
        if self.military_time:
            self.time_format = "%A, %e %B %Y %H:%M"

        self.message_created_at, self.message_edited_at = self.set_time()
        self.meta_data = meta_data
        self.forwarded = False
        self.reference_html = ""

    def get_message_snapshots(self):
        if hasattr(self.message, "message_snapshots"):
            return self.message.message_snapshots
        elif hasattr(self.message, "snapshots"):
            return self.message.snapshots
        return []

    @staticmethod
    def _collect_attachment_urls(attachment):
        urls = set()
        for attr in ("url", "proxy_url"):
            value = getattr(attachment, attr, None)
            if value:
                urls.add(str(value))
        return urls

    @staticmethod
    def _embed_has_non_image_content(embed) -> bool:
        return bool(
            getattr(embed, "title", None)
            or getattr(embed, "description", None)
            or (getattr(embed, "fields", None) and len(embed.fields) > 0)
            or (getattr(embed, "author", None) and getattr(embed.author, "name", None))
            or (getattr(embed, "footer", None) and getattr(embed.footer, "text", None))
            or (getattr(embed, "thumbnail", None) and getattr(embed.thumbnail, "url", None))
        )

    def _is_duplicate_image_embed(self, embed, attachment_urls) -> bool:
        if not attachment_urls:
            return False
        image = getattr(embed, "image", None)
        if not image:
            return False
        image_url = getattr(image, "proxy_url", None) or getattr(image, "url", None)
        if not image_url or str(image_url) not in attachment_urls:
            return False
        if self._embed_has_non_image_content(embed):
            return False
        return True

    async def construct_message(
        self,
    ) -> (str, dict):
        if discord.MessageType.pins_add == self.message.type:
            await self.build_pin()
        elif discord.MessageType.thread_created == self.message.type:
            await self.build_thread()
        elif discord.MessageType.recipient_remove == self.message.type:
            await self.build_thread_remove()
        elif discord.MessageType.recipient_add == self.message.type:
            await self.build_thread_add()
        else:
            await self.build_message()
        return self.message_html, self.meta_data

    async def build_message(self):
        await self.build_content()
        await self.build_reference()
        await self.build_interaction()
        await self.build_sticker()
        await self.build_assets()
        await self.wrap_forwarded()
        await self.build_message_template()
        await self.build_meta_data()

    async def build_pin(self):
        await self.generate_message_divider(channel_audit=True)
        await self.build_pin_template()

    async def build_thread(self):
        await self.generate_message_divider(channel_audit=True)
        await self.build_thread_template()

    async def build_thread_remove(self):
        await self.generate_message_divider(channel_audit=True)
        await self.build_remove()

    async def build_thread_add(self):
        await self.generate_message_divider(channel_audit=True)
        await self.build_add()

    async def build_meta_data(self):
        user_id = self.message.author.id

        if user_id in self.meta_data:
            self.meta_data[user_id][4] += 1
        else:
            user_name_discriminator = await discriminator(self.message.author.name, self.message.author.discriminator)
            user_created_at = self.message.author.created_at
            user_bot = _gather_user_bot(self.message.author)
            user_avatar = (
                self.message.author.display_avatar
                if self.message.author.display_avatar
                else DiscordUtils.default_avatar
            )
            user_joined_at = self.message.author.joined_at if hasattr(self.message.author, "joined_at") else None
            user_display_name = (
                f'<div class="meta__display-name">{escape(self.message.author.display_name)}</div>'
                if self.message.author.display_name != self.message.author.name
                else ""
            )
            self.meta_data[user_id] = [
                user_name_discriminator,
                user_created_at,
                user_bot,
                user_avatar,
                1,
                user_joined_at,
                user_display_name,
            ]

    async def build_content(self):
        if not self.message.content and not self.get_message_snapshots():
            self.rendered_content = ""
            return

        if self.message_edited_at:
            self.message_edited_at = _set_edit_at(self.message_edited_at)

        snapshots = self.get_message_snapshots()
        if snapshots:
            combined = f"{self.message.content} {' '.join(s.content for s in snapshots if hasattr(s, 'content'))}"
            self.forwarded = True
        else:
            combined = self.message.content

        combined = html.escape(combined or "")


        self.rendered_content = await fill_out(
            self.guild,
            message_content,
            [
                ("MESSAGE_CONTENT", combined, PARSE_MODE_MARKDOWN),
                ("EDIT", self.message_edited_at, PARSE_MODE_NONE),
            ],
        )

    async def build_reference(self):
        if not self.message.reference:
            return

        message: discord.Message = self.message_dict.get(self.message.reference.message_id)

        if not message:
            try:
                message: discord.Message = await self.message.channel.fetch_message(self.message.reference.message_id)
            except (discord.NotFound, discord.HTTPException) as e:
                if not self.forwarded and isinstance(e, discord.NotFound):
                    self.reference_html = message_reference_unknown
                return

        is_bot = _gather_user_bot(message.author)
        user_colour = await self._gather_user_colour(message.author)

        icon = ""
        dummy = ""

        def get_interaction_status(interaction_message):
            if hasattr(interaction_message, "interaction_metadata"):
                return interaction_message.interaction_metadata
            return interaction_message.interaction

        interaction_status = get_interaction_status(message)
        if not interaction_status and (message.embeds or message.attachments):
            icon = DiscordUtils.reference_attachment_icon
            dummy = "Click to see attachment"
        elif interaction_status:
            icon = DiscordUtils.interaction_command_icon
            dummy = "Click to see command"

        content = message.content or dummy

        _, message_edited_at = self.set_time(message)

        if message_edited_at:
            message_edited_at = _set_edit_at(message_edited_at)

        avatar_url = message.author.display_avatar if message.author.display_avatar else DiscordUtils.default_avatar
        self.reference_html = await fill_out(
            self.guild,
            message_reference,
            [
                ("AVATAR_URL", str(avatar_url), PARSE_MODE_URL),
                ("BOT_TAG", is_bot, PARSE_MODE_NONE),
                ("NAME_TAG", await discriminator(message.author.name, message.author.discriminator), PARSE_MODE_TEXT),
                ("NAME", message.author.display_name, PARSE_MODE_TEXT),
                ("USER_COLOUR", user_colour, PARSE_MODE_NONE),
                ("CONTENT", html.escape(content.replace("\n", "")), PARSE_MODE_REFERENCE),
                ("EDIT", message_edited_at, PARSE_MODE_NONE),
                ("ICON", icon, PARSE_MODE_NONE),
                ("USER_ID", str(message.author.id), PARSE_MODE_NONE),
                ("MESSAGE_ID", str(self.message.reference.message_id), PARSE_MODE_NONE),
            ],
        )

    async def build_interaction(self):
        if hasattr(self.message, "interaction_metadata"):
            if not self.message.interaction_metadata:
                self.interaction = ""
                return
            command = "a slash command"
            user = self.message.interaction_metadata.user
            interaction_id = self.message.interaction_metadata.id
        elif self.message.interaction:
            command = f"/{self.message.interaction.name}"
            user = self.message.interaction.user
            interaction_id = self.message.interaction.id
        else:
            self.interaction = ""
            return

        is_bot = _gather_user_bot(user)
        user_colour = await self._gather_user_colour(user)
        avatar_url = user.display_avatar if user.display_avatar else DiscordUtils.default_avatar

        self.interaction = await fill_out(
            self.guild,
            message_interaction,
            [
                ("AVATAR_URL", str(avatar_url), PARSE_MODE_URL),
                ("BOT_TAG", is_bot, PARSE_MODE_NONE),
                ("NAME_TAG", await discriminator(user.name, user.discriminator), PARSE_MODE_TEXT),
                ("NAME", user.display_name, PARSE_MODE_TEXT),
                ("COMMAND", str(command), PARSE_MODE_TEXT),
                ("USER_COLOUR", user_colour, PARSE_MODE_NONE),
                ("FILLER", "used ", PARSE_MODE_NONE),
                ("USER_ID", str(user.id), PARSE_MODE_NONE),
                ("INTERACTION_ID", str(interaction_id), PARSE_MODE_NONE),
            ],
        )

    async def build_sticker(self):
        sticker = None
        sticker_image_url = None

        if self.message.stickers and hasattr(self.message.stickers[0], "url"):
            sticker_image_url = self.message.stickers[0].url
        if not sticker_image_url:
            for snapshot in self.get_message_snapshots():
                if hasattr(snapshot, "stickers") and snapshot.stickers and hasattr(snapshot.stickers[0], "url"):
                    sticker_image_url = snapshot.stickers[0].url
                    self.reference_html = ""
                    break

        if not sticker_image_url:
            return

        if sticker_image_url.endswith(".json"):
            try:
                sticker = await self.message.stickers[0].fetch()
            except (discord.HTTPException, IndexError):
                for snapshot in self.get_message_snapshots():
                    if hasattr(snapshot, "stickers") and snapshot.stickers and hasattr(snapshot.stickers[0], "url"):
                        try:
                            sticker = await snapshot.stickers[0].fetch()
                        except discord.HTTPException:
                            pass
                        break
            if sticker is None:
                return
            sticker_image_url = (
                f"https://cdn.jsdelivr.net/gh/mahtoid/DiscordUtils@master/stickers/{sticker.pack_id}/{sticker.id}.gif"
            )

        self.rendered_content = await fill_out(
            self.guild,
            img_attachment,
            [
                ("ATTACH_URL", str(sticker_image_url), PARSE_MODE_URL),
                ("ATTACH_URL_THUMB", str(sticker_image_url), PARSE_MODE_URL),
            ],
        )

    @staticmethod
    def calculate_grid_splits(n):
        if n <= 4:
            return [n]
        if n == 9:
            return [9]
        if n == 5:
            return [2, 3]
        if n == 6:
            return [3, 3]
        if n == 7:
            return [1, 3, 3]
        if n == 8:
            return [2, 3, 3]
        if n == 10:
            return [1, 9]

        if n > 9:
            res = MessageConstruct.calculate_grid_splits(n - 9)
            res.append(9)
            return res
        return [n]

    async def build_assets(self):
        processed_attachments = []
        attachment_urls = set()

        for snapshot in self.get_message_snapshots():
            if hasattr(snapshot, "embeds"):
                for se in snapshot.embeds:
                    self.forwarded_embeds += await Embed(se, self.guild).flow()
                    self.reference_html = ""

        for a in self.message.attachments:
            if self.attachment_handler and isinstance(self.attachment_handler, AttachmentHandler):
                a = await self.attachment_handler.process_asset(a)
            processed_attachments.append(a)
            attachment_urls.update(self._collect_attachment_urls(a))

        for e in self.message.embeds:
            if self._is_duplicate_image_embed(e, attachment_urls):
                continue
            self.embeds += await Embed(e, self.guild, self.pytz_timezone, self.military_time).flow()

        media_group = []

        async def flush_media_group(group):
            if not group:
                return ""
            html_output = ""
            splits = self.calculate_grid_splits(len(group))
            start = 0
            for s in splits:
                html_output += await AttachmentGrid(group[start : start + s], self.guild, len(group)).flow()
                start += s
            return html_output

        for a in processed_attachments:
            if a.content_type and ("image" in a.content_type or "video" in a.content_type):
                media_group.append(a)
            else:
                if media_group:
                    self.attachments += await flush_media_group(media_group)
                    media_group = []
                self.attachments += await Attachment(a, self.guild).flow()

        if media_group:
            self.attachments += await flush_media_group(media_group)

        for snapshot in self.get_message_snapshots():
            if hasattr(snapshot, "attachments"):
                for sa in snapshot.attachments:
                    if self.attachment_handler:
                        sa = await self.attachment_handler.process_asset(sa)
                    self.attachments += await Attachment(sa, self.guild).flow()
                    self.reference_html = ""

        for c in self.message.components:
            self.components += await Component(c, self.guild, self.message.attachments).flow()

        for snapshot in self.get_message_snapshots():
            if hasattr(snapshot, "components"):
                for ac in snapshot.components:
                    self.components += await Component(ac, self.guild).flow()
                    self.reference_html = ""

        if self.message.reactions:
            reaction_results = []
            for r in self.message.reactions:
                reaction_results.append(await Reaction(r, self.guild, self.fetch_reactors).flow())
            self.reactions += "".join(reaction_results)

        if self.reactions:
            self.reactions = f'<div class="chatlog__reactions">{self.reactions}</div>'

    async def wrap_forwarded(self):
        if not self.forwarded:
            return

        self.rendered_content = (
            f'<div class="quote"><div>{message_forwarded}{self.rendered_content}'
            f"{self.attachments}{self.forwarded_embeds}{self.components}</div></div>"
        )

        self.attachments = ""
        self.forwarded_embeds = ""
        self.components = ""

    async def build_message_template(self):
        started = await self.generate_message_divider()

        if started:
            return self.message_html

        self.message_html += await fill_out(
            self.guild,
            message_body,
            [
                ("MESSAGE_ID", str(self.message.id)),
                ("MESSAGE_CONTENT", self.rendered_content, PARSE_MODE_NONE),
                ("EMBEDS", self.embeds, PARSE_MODE_NONE),
                ("ATTACHMENTS", self.attachments, PARSE_MODE_NONE),
                ("COMPONENTS", self.components, PARSE_MODE_NONE),
                ("EMOJI", self.reactions, PARSE_MODE_NONE),
                ("TIMESTAMP", self.message_created_at, PARSE_MODE_NONE),
                ("TIME", self.message_created_at.split(maxsplit=4)[4], PARSE_MODE_NONE),
            ],
        )

        return self.message_html

    def _generate_message_divider_check(self):
        return bool(
            self.previous_message is None
            or self.reference_html != ""
            or self.previous_message.type is not discord.MessageType.default
            or self.interaction != ""
            or self.previous_message.author.id != self.message.author.id
            or self.message.webhook_id is not None
            or self.message.created_at > (self.previous_message.created_at + timedelta(minutes=4))
        )

    async def generate_message_divider(self, channel_audit=False):
        if channel_audit or self._generate_message_divider_check():
            if self.previous_message is not None:
                self.message_html += await fill_out(self.guild, end_message, [])

            if channel_audit:
                self.audit = True
                return

            followup_symbol = ""
            is_bot = _gather_user_bot(self.message.author)
            avatar_url = self.message.author.display_avatar
            if not avatar_url:
                avatar_url = DiscordUtils.default_avatar

            if self.reference_html != "" or self.interaction:
                followup_symbol = "<div class='chatlog__followup-symbol'></div>"

            time = self.message.created_at
            if not self.message.created_at.tzinfo:
                time = timezone("UTC").localize(time)

            if self.military_time:
                default_timestamp = time.astimezone(timezone(self.pytz_timezone)).strftime("%d-%m-%Y %H:%M")
            else:
                default_timestamp = time.astimezone(timezone(self.pytz_timezone)).strftime("%d-%m-%Y %I:%M %p")

            self.message_html += await fill_out(
                self.guild,
                start_message,
                [
                    ("REFERENCE_SYMBOL", followup_symbol, PARSE_MODE_NONE),
                    (
                        "REFERENCE",
                        self.reference_html if self.reference_html else self.interaction,
                        PARSE_MODE_NONE,
                    ),
                    ("AVATAR_URL", str(avatar_url), PARSE_MODE_URL),
                    ("AVATAR_DECORATION", str(self._gather_avatar_decoration()), PARSE_MODE_NONE),
                    (
                        "NAME_TAG",
                        await discriminator(self.message.author.name, self.message.author.discriminator),
                        PARSE_MODE_NONE,
                    ),
                    ("USER_ID", str(self.message.author.id)),
                    ("USER_COLOUR", await self._gather_user_colour(self.message.author), PARSE_MODE_NONE),
                    ("USER_ICON", await self._gather_user_icon(self.message.author), PARSE_MODE_NONE),
                    ("NAME", self.message.author.display_name, PARSE_MODE_TEXT),
                    ("BOT_TAG", str(is_bot), PARSE_MODE_NONE),
                    ("TIMESTAMP", str(self.message_created_at)),
                    ("DEFAULT_TIMESTAMP", str(default_timestamp), PARSE_MODE_NONE),
                    ("MESSAGE_ID", str(self.message.id)),
                    ("MESSAGE_CONTENT", self.rendered_content, PARSE_MODE_NONE),
                    ("EMBEDS", self.embeds, PARSE_MODE_NONE),
                    ("ATTACHMENTS", self.attachments, PARSE_MODE_NONE),
                    ("COMPONENTS", self.components, PARSE_MODE_NONE),
                    ("EMOJI", self.reactions, PARSE_MODE_NONE),
                ],
            )

            return True

    async def build_pin_template(self):
        self.message_html += await fill_out(
            self.guild,
            message_pin,
            [
                ("PIN_URL", DiscordUtils.pinned_message_icon, PARSE_MODE_NONE),
                ("USER_COLOUR", await self._gather_user_colour(self.message.author), PARSE_MODE_NONE),
                ("NAME", self.message.author.display_name, PARSE_MODE_TEXT),
                (
                    "NAME_TAG",
                    await discriminator(self.message.author.name, self.message.author.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("MESSAGE_ID", str(self.message.id), PARSE_MODE_NONE),
                (
                    "REF_MESSAGE_ID",
                    str(self.message.reference.message_id) if self.message.reference else "",
                    PARSE_MODE_NONE,
                ),
            ],
        )

    async def build_thread_template(self):
        self.message_html += await fill_out(
            self.guild,
            message_thread,
            [
                ("THREAD_URL", DiscordUtils.thread_channel_icon, PARSE_MODE_NONE),
                ("THREAD_NAME", self.message.content, PARSE_MODE_TEXT),
                ("USER_COLOUR", await self._gather_user_colour(self.message.author), PARSE_MODE_NONE),
                ("NAME", self.message.author.display_name, PARSE_MODE_TEXT),
                (
                    "NAME_TAG",
                    await discriminator(self.message.author.name, self.message.author.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("MESSAGE_ID", str(self.message.id), PARSE_MODE_NONE),
            ],
        )

    async def build_remove(self):
        removed_member: discord.Member = self.message.mentions[0]
        self.message_html += await fill_out(
            self.guild,
            message_thread_remove,
            [
                ("THREAD_URL", DiscordUtils.thread_remove_recipient, PARSE_MODE_NONE),
                ("USER_COLOUR", await self._gather_user_colour(self.message.author), PARSE_MODE_NONE),
                ("NAME", self.message.author.display_name, PARSE_MODE_TEXT),
                (
                    "NAME_TAG",
                    await discriminator(self.message.author.name, self.message.author.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("RECIPIENT_USER_COLOUR", await self._gather_user_colour(removed_member), PARSE_MODE_NONE),
                ("RECIPIENT_NAME", removed_member.display_name, PARSE_MODE_TEXT),
                (
                    "RECIPIENT_NAME_TAG",
                    await discriminator(removed_member.name, removed_member.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("MESSAGE_ID", str(self.message.id), PARSE_MODE_NONE),
            ],
        )

    async def build_add(self):
        removed_member: discord.Member = self.message.mentions[0]
        self.message_html += await fill_out(
            self.guild,
            message_thread_add,
            [
                ("THREAD_URL", DiscordUtils.thread_add_recipient, PARSE_MODE_NONE),
                ("USER_COLOUR", await self._gather_user_colour(self.message.author), PARSE_MODE_NONE),
                ("NAME", self.message.author.display_name, PARSE_MODE_TEXT),
                (
                    "NAME_TAG",
                    await discriminator(self.message.author.name, self.message.author.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("RECIPIENT_USER_COLOUR", await self._gather_user_colour(removed_member), PARSE_MODE_NONE),
                ("RECIPIENT_NAME", removed_member.display_name, PARSE_MODE_TEXT),
                (
                    "RECIPIENT_NAME_TAG",
                    await discriminator(removed_member.name, removed_member.discriminator),
                    PARSE_MODE_NONE,
                ),
                ("MESSAGE_ID", str(self.message.id), PARSE_MODE_NONE),
            ],
        )

    @cache()
    async def _gather_member(self, author: discord.Member):
        member = self.guild.get_member(author.id)

        if member:
            return member

        try:
            return await self.guild.fetch_member(author.id)
        except Exception:
            return None

    async def _gather_user_colour(self, author: discord.Member):
        member = await self._gather_member(author)
        colour = str(getattr(member, "colour", "") or "")
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", colour) or colour.lower() == "#000000":
            colour = "#FFFFFF"
        return f"color: {colour};"

    async def _gather_user_icon(self, author: discord.Member):
        member = await self._gather_member(author)

        if not member:
            return ""

        icon = None
        if hasattr(member, "display_icon") and member.display_icon:
            icon = member.display_icon
        elif hasattr(member, "top_role") and member.top_role and member.top_role.icon:
            icon = member.top_role.icon

        # display_icon can also be a unicode emoji, which isn't a URL.
        icon_url = safe_url(icon)
        if not icon_url:
            return ""
        return f"<img class='chatlog__role-icon' src='{icon_url}' alt='Role Icon'>"

    def _gather_avatar_decoration(self):
        decoration = getattr(self.message.author, "avatar_decoration", None)
        if not decoration:
            return ""
        
        decoration_url = safe_url(getattr(decoration, "url", None))
        if not decoration_url:
            return ""

        return f'<img class="chatlog__avatar-decoration" src="{decoration_url}" alt="Avatar Decoration">'

    def set_time(self, message: Optional[discord.Message] = None):
        message = message if message else self.message
        created_at_str = self.to_local_time_str(message.created_at)
        edited_at_str = self.to_local_time_str(message.edited_at) if message.edited_at else ""

        return created_at_str, edited_at_str

    def to_local_time_str(self, time):
        if not self.message.created_at.tzinfo:
            time = timezone("UTC").localize(time)

        local_time = time.astimezone(timezone(self.pytz_timezone))

        return local_time.strftime(self.time_format)


async def gather_messages(
    messages: List[discord.Message],
    guild: discord.Guild,
    pytz_timezone,
    military_time,
    attachment_handler: Optional[AttachmentHandler],
    fetch_reactors: bool = True,
) -> (str, dict):
    message_html_chunks: List[str] = []
    meta_data: dict = {}
    previous_message: Optional[discord.Message] = None

    message_dict = {message.id: message for message in messages}

    messages = list(messages)
    if messages:
        messages[0] = await resolve_thread_starter(guild, messages[0])

    for message in messages:
        content_html, meta_data = await MessageConstruct(
            message,
            previous_message,
            pytz_timezone,
            military_time,
            guild,
            meta_data,
            message_dict,
            attachment_handler,
            fetch_reactors,
        ).construct_message()

        message_html_chunks.append(content_html)
        previous_message = message

    message_html_chunks.append("</div>")
    return "".join(message_html_chunks), meta_data


async def resolve_thread_starter(guild: discord.Guild, message: discord.Message) -> discord.Message:
    """A thread's first message points at the message the thread was started from; show that one instead."""
    if "thread" not in str(message.channel.type) or not message.reference:
        return message

    reference = message.reference
    try:
        channel = guild.get_channel(reference.channel_id) or await guild.fetch_channel(reference.channel_id)
        starter = await channel.fetch_message(reference.message_id)
    except discord.HTTPException:
        return message

    starter.reference = None
    return starter
